This library is a modified version of MicroBridge downloaded from  http://code.google.com/p/microbridge/. 
1.Minor modification is done to correctly configure SPI port of Seeeduino ADK Main Board. 
This modification can also be used for any Any Android ADK Reference board

2.A new sketch SeeeduinoADKDemo.pde is added to showcase Seeeduino ADK Main Board.
